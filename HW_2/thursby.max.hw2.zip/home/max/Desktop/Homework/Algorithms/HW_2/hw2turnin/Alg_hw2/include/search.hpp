#include <iostream>
#include <graph.hpp>
#include <queue.hpp>
#include <stack.hpp>

void bfs(Graph &G, int start, int destination);
